terminal_black = True
mode = "normal"
# this is where the folder of your game is. If you want saves in a custom folder, that folder must have a folder called saves
game_directory = "/Users/ev/Downloads/thearabgame-main/gamepackage"
debug = True
hasmods = False
