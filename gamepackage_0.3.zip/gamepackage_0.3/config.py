terminal_black = True
mode = "normal"
debug = False
hasmods = False