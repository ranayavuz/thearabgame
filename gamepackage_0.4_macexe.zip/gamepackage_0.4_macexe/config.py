terminal_black = True
mode = "normal"

debug = True
hasmods = False
# if you want to use a custom folder for the game package, set this to True
customfolder = False
# this will only work if customfolder is set to True
customdir = "gamepackage"